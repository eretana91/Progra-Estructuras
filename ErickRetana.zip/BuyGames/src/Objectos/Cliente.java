package Objectos;

/**
 *
 * @author Erick Retana Sánchez
 *
 *
 */
public class Cliente extends Persona {

    public Cliente(String nombre, String apellido, String direccion, String telefono, String email, String cedula) {
        super(nombre, apellido, direccion, telefono, email, cedula);
    }

}
