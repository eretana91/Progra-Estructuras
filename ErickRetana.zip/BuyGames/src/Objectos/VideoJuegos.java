package Objectos;

public class VideoJuegos {

    private String nombre;
    private int precio;
    private char categoria;
    private String rutaImagen;

    public void VideoJuegos(String nombre, int precio, char categoria, String rutaImagen) {
        this.nombre = nombre;
        this.precio = precio;
        this.categoria = categoria;
        this.rutaImagen = rutaImagen;
    }
}
